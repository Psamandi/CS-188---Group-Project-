// This allows the Javascript code inside this block to only run when the page
// has finished loading in the browser.

var localTime = new Date();

var OpenHalls = document.getElementById('OpenNow');

//For testing..
//S4, M5, T6, W7, T8, F9, S10
// localTime.setDate(10);
// localTime.setHours(19);
// localTime.setMinutes(40);

var day = localTime.getDay();
var hour = localTime.getHours();
var minute = localTime.getMinutes();
// console.log(day+ ' ' + hour + ' ' + minute);

var timeframe = hour*100+minute;
// console.log(timeframe);

var arr = [];
//weekdays
if(day >= 1 && day <= 5) {
  //Bruin Plate (Breakfast Grab and Go)
  if(timeframe >= 700 && timeframe <= 1000)
    arr.push('Bruin Plate');
  
  //Bruin Cafe
  if((timeframe >= 700 && timeframe <= 1100) 
    ||(timeframe >= 1100 && timeframe <= 1330)
    ||(timeframe >= 1400 && timeframe <= 1930)
    ||(timeframe >= 2000 && timeframe <= 2159))
    arr.push('Bruin Cafe');
  
  //Cafe 1919
  if((timeframe >= 1100 && timeframe <= 1600) 
    ||(timeframe >= 1700 && timeframe <= 2159))
    arr.push('Cafe 1919');

  //Rendezvous
  if((timeframe >= 700 && timeframe <= 1030) 
    ||(timeframe >= 1130 && timeframe <= 1600)
    ||(timeframe >= 1700 && timeframe <= 2159))
    arr.push('Rendezvous');

  //The Study at Hedrick
  if((timeframe >= 700 && timeframe <= 1100) 
    ||(timeframe >= 1200 && timeframe <= 1700)
    ||(timeframe >= 1730 && timeframe <= 2159)
    ||(timeframe >= 0 && timeframe <= 200))
    arr.push('The Study at Hedrick');
} else { //Weekends  
  //Bruin Cafe
  if((timeframe >= 1500 && timeframe <= 1930) 
    ||(timeframe >= 2100 && timeframe <= 2359))
    arr.push('Bruin Cafe');

  //Rendezvous
  if((timeframe >= 1000 && timeframe <= 1400) 
    ||(timeframe >= 1700 && timeframe <= 2000))
    arr.push('Rendezvous');

  //The Study at Hedrick
  if((timeframe >= 1100 && timeframe <= 1630)
    ||(timeframe >= 1700 && timeframe <= 2359)
    ||(timeframe >= 0 && timeframe <= 200))
    arr.push('The Study at Hedrick');
}

if(arr.length == 0) {
    arr.push('No Open Places');
}

// console.log(arr);
OpenHalls.innerHTML = arr.toString();