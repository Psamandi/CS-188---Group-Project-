// This allows the Javascript code inside this block to only run when the page
// has finished loading in the browser.

var localTime = new Date();

var OpenHalls = document.getElementById('OpenNow');



//For testing..
//S4, M5, T6, W7, T8, F9, S10
// localTime.setDate(10);
// localTime.setHours(19);
// localTime.setMinutes(40);

var day = localTime.getDay();
var hour = localTime.getHours();
var minute = localTime.getMinutes();
// console.log(day+ ' ' + hour + ' ' + minute);

var timeframe = hour*100+minute;
// console.log(timeframe);


var arr = new 
Array("assets/bruincafe-logo.jpg",
  "assets/cafe1919-logo.jpg","assets/rendezvous-logo.jpg",
  "assets/hedrickstudy-logo.jpg");




//weekdays
if(day >= 1 && day <= 5) {
  //Bruin Plate (Breakfast Grab and Go)
//   if(timeframe >= 700 && timeframe <= 1000){
//   // arr.push('Bruin Plate');
//   //created image element
//   var img = document.createElement("img");
// //settiing the source element of the image to first element of the array 
//   img.src = arr[0]; 
// //Append the image to OpenHall element
//   OpenHalls.appendChild(img); 
  // }

  var is_empty = true;
  
  //Bruin Cafe
  if((timeframe >= 700 && timeframe <= 1100) 
    ||(timeframe >= 1100 && timeframe <= 1330)
    ||(timeframe >= 1400 && timeframe <= 1930)
    ||(timeframe >= 2000 && timeframe <= 2359)){
    // arr.push('Bruin Cafe');
    var img = document.createElement('img');
    img.src = arr[0]; 
    var link = document.createElement('a');
    link.href = "bruincafe_menu.html";
    link.appendChild(img);
    OpenHalls.appendChild(link); 
    is_empty = false;
    }

  
  //Cafe 1919
  if((timeframe >= 1100 && timeframe <= 1600) 
    ||(timeframe >= 1700 && timeframe <= 2359)){
    // arr.push('Cafe 1919');
  var img = document.createElement('img');
    img.src = arr[1]; 
    var link = document.createElement('a');
    link.href = "cafe1919_menu.html";
    link.appendChild(img);
    OpenHalls.appendChild(link); 
    is_empty = false;
}

  //Rendezvous
  if((timeframe >= 700 && timeframe <= 1030) 
    ||(timeframe >= 1130 && timeframe <= 1600)
    ||(timeframe >= 1700 && timeframe <= 2359)){
    // arr.push('Rendezvous');
  var img = document.createElement('img');
    img.src = arr[2]; 
    var link = document.createElement('a');
    link.href = "rendezvous_menu.html";
    link.appendChild(img);
    OpenHalls.appendChild(link); 
    is_empty = false;
  }


  //The Study at Hedrick
  if((timeframe >= 700 && timeframe <= 1100) 
    ||(timeframe >= 1200 && timeframe <= 1700)
    ||(timeframe >= 1730 && timeframe <= 2359)
    ||(timeframe >= 0 && timeframe <= 200)){
    // arr.push('The Study at Hedrick');
  var img = document.createElement('img');
    img.src = arr[3]; 
    var link = document.createElement('a');
    link.href = "hedrick_study_menu.html";
    link.appendChild(img);
    OpenHalls.appendChild(link);
    is_empty = false; 
}
// else 
//     document.getElementById('OpenNow').innerHTML="No Open Halls";
if (is_empty) {
  OpenHalls.innerHTML = "No Open Halls";
  OpenHalls.appendChild(document.createElement('br'));
}

  
} else { //Weekends  
  //Bruin Cafe
  var is_empty = true;
  if((timeframe >= 1500 && timeframe <= 1930) 
    ||(timeframe >= 2100 && timeframe <= 2359)){
    // arr.push('Bruin Cafe');
  var img = document.createElement('img');
  img.src = arr[0]; 
  var link = document.createElement('a');
  link.href = "bruincafe_menu.html";
  link.appendChild(img);
  OpenHalls.appendChild(link); 
  is_empty = false;
}
  

  //Rendezvous
  if((timeframe >= 1000 && timeframe <= 1400) 
    ||(timeframe >= 1700 && timeframe <= 2000)){
    // arr.push('Rendezvous');
  var img = document.createElement('img');
    img.src = arr[2]; 
    var link = document.createElement('a');
    link.href = "rendezvous_menu.html";
    link.appendChild(img);
    OpenHalls.appendChild(link); 
    is_empty = false;
  }

  //The Study at Hedrick
  if((timeframe >= 1100 && timeframe <= 1630)
    ||(timeframe >= 1700 && timeframe <= 2359)
    ||(timeframe >= 0 && timeframe <= 200)){
     // arr.push('The Study at Hedrick');
  var img = document.createElement('img');
    img.src = arr[3]; 
    var link = document.createElement('a');
    link.href = "hedrick_study_menu.html";
    link.appendChild(img);
    OpenHalls.appendChild(link); 
    is_empty = false;
  }
  // else 
  //   document.getElementById('OpenNow').innerHTML="No Open Halls";
  if (is_empty) {
  OpenHalls.innerHTML = "No Open Halls";
  OpenHalls.appendChild(document.createElement('br'));
}


}



// if(arr.length == 0) {
//     var img = document.createElement("img");
  
// }

// $('#OpenNow').empty();
// for (i=0; i<arr.length; i++){
//   var img = document.createElement("img");
//   img.src = arr[i];
//   OpenHalls.appendChild(img);
// }

// console.log(arr);
// OpenHalls.innerHTML = arr.toString();