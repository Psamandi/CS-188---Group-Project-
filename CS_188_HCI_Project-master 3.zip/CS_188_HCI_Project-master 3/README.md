# Welcome to our team's CS 188: Human Computer Interaction project!

Our team name is Lettuce Olive Better and we set out to improve the on-campus dining experience in the quick serve restaurants.

## Public website: https://devandutta.github.io/CS_188_HCI_Project/

## Team Members:
* Devan Dutta
* Prit Joshi
* Brian Lee
* Pariya Samandi

## Our goals are to:
1. Provide an online ordering system for students.
2. Provide health information for entrees so that students can eat healthier.
3. Provide a means of feedback between students and the dining system so that students can rate their ordered entrees.

## Directory Structure
* `README.md`: This file!
* `/docs`: With GitHub Pages, the convention is to have such a directory to hold all the website content. Inside this directory, you'll find all the code for the website.
  * `/docs/assets/`: Contains images, utility functions for time, an external button library, and external star rating library
  * `/docs/jquery/`: The jQuery library we are using for this project.
  * `/docs/overhang/`: Used for notifying the user of wait time for his/her order.
  * `/docs/stars/`: Contains javascript for enabling star ratings of entrees.
  * `/docs/sweetalert2/`: An external library used for order confirmation overlays.
  * `/docs/index.html`: The landing page of the website.
  * `/docs/menus.html`: The menu page of the website.
  * `/docs/p-script.js`: Javascript used for the Past Orders page that handles querying Firebase and dynamically rendering past orders on the page.
  * `/docs/past_orders.html`: The page that displays a user's past orders and provides a star rating feedback system, as well as a Re-Order feature.
  * `/docs/script.js`: The main Javascript that the entire website makes use of (contains common utility functions as well as activities that should be done for each page). Also includes the Ordering functionality.
  * `/docs/settings.html`: The settings page for the user.
  * `/docs/styles.css`: Contains all CSS styling for the website.

## External Libraries/Frameworks
* SweetAlert2: https://sweetalert2.github.io
* jQuery: https://jquery.com
* Firebase Database: https://firebase.google.com
* Pushy Buttons: https://iraul.github.io/pushy-buttons/
* Stars: https://github.com/viniciusmichelutti/jquery-stars
* Overhang: https://github.com/paulkr/overHang.js/

## Acknowledgments
We give special thanks to Professor Uichin Lee, as well as our TA, Manoj Reddy. Their continual guidance throughout the project was incredibly helpful and also steered us in the right direction for each phase of the implementation.
